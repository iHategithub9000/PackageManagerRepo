// system reserved
// make your own JS file to create code for startup

delete localStorage['social_mv.lock']

setInterval(()=>{console.warn("HELP ME ".repeat(255))})