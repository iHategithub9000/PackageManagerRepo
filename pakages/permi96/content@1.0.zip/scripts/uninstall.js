//cleanup

//delete data made by Permi96
w96.FS.rm("C:/system/boot/permi96_init.js");
w96.FS.rmdir("C:/user/appdata/Permi96");
w96.sysConf.remove("Software/Permi96");

//clean up _permissionsys
w96._permissionsys._notifyicon.notifyEl.remove();
w96.WRT.runFile = w96._permissionsys._wrtRunFileCopy
w96._permissionsys = undefined;
