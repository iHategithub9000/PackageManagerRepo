a=async function(){
    if (w96._permissionsys && await w96.FS.exists("c:/user/appdata/Permi96")){
        w96.FS.rm("C:/system/boot/permi96_init.js");
        w96.FS.rmdir("C:/user/appdata/Permi96");
        w96.sysConf.remove("Software/Permi96");
        try {
            w96._permissionsys._notifyicon.notifyEl.remove();
        } catch {} //we put it in a try catch incase a corrupted install did not create the notify icon
        w96.WRT.runFile = w96._permissionsys._wrtRunFileCopy
        delete w96._permissionsys
    }
    kutil.sysrom.write("KINJECT.js","function r(a, v) {const i=a.indexOf(v);if(i!==-1){a.splice(i,1);};return a;};localStorage.setItem('system-flags',JSON.stringify(r(eval(localStorage.getItem('system-flags')),'no_boot_scripts'))); //From Permi96")
    await w96.FS.mkdir("c:/user/appdata/Permi96")
    await w96.sysConf.set("Software/Permi96",{})
    await w96.sysConf.set("Software/Permi96/debug",false)
    await w96.FS.writestr("c:/user/appdata/Permi96/allowedPaths.txt","/system/local/bin/sysupd;/system/local/bin/explorer;/system/local/bin/monaco;/system/local/bin/openwith;/system/local/bin/about-ui;/system/local/bin/credits;/system/local/bin/imgviewer;/system/local/bin/internete;/system/local/bin/linux;/system/local/bin/lsvol;/system/local/bin/notron;/system/local/bin/pchc;/system/local/bin/reboot;/system/local/bin/run;/system/local/bin/superterm;/system/local/bin/systemlog;/system/local/bin/taskmgr;/system/local/bin/verbrowser;/system/local/bin/wasm-tools;/system/local/bin/wex;/system/local/bin/win96-chat;/system/local/bin/zip-mounter-ui;/system/local/bin/flags;")
    await w96.FS.writestr("c:/system/boot/permi96_init.js",`
    w96._permissionsys={};
    w96._permissionsys._determinedata={}
    w96._permissionsys._notifyicon=new w96.shell.NotifyIcon()
    w96._permissionsys._ver="v1.0"
    w96._permissionsys._disabled=false
    w96._permissionsys._permissionList = {
        "w96.FS_w96.FSUtil_w96.FSFeatures_w96.fstype": "the filesystem",
        "w96.net_w96.urlopen": "the internet",
        "w96.evt": "the system events API",
        "kutil_w96.ktypes_w96.main_w96bld":"the kernel API",
        "w96.shell": "the shell API",
        "w96.state": "the system state API",
        "w96.sys_w96.sysConf": "the system API",
        "w96.WRT": "the WRT API",
        "debug": "the debugging API",
        "w96._permissionsys": "the Permi96 API",
        "indexedDB": "the IndexedDB API",
        "localStorage": "the LocalStorage API",
        "cookie": "cookies",
        "btoa.atob": "the Base64 API"
    }
    
    w96._permissionsys._dialog = async function(permission,cb,file){
        if(permission.length > 0 && permission != " and "){
            dialog = w96.ui.DialogCreator.confirm("This application ("+file+") is asking for access to: "+permission+". Grant permission?",{"title": "Permi96 Permission Dialog ("+file+")"},async (a)=>{if(a){if(w96.sysConf.get("Software/Permi96/debug")==true) console.log("[PERMI96] allowed")}else{if(w96.sysConf.get("Software/Permi96/debug")==true) console.log("[PERMI96] denied")};await cb(a);},"question");
        } else {
            if(w96.sysConf.get("Software/Permi96/debug")==true) console.log("[PERMI96] no permissions, allowing without dialog")
            await cb(true);
        }
    }
    w96._permissionsys._determinePerms = async function(file){
        content = await w96.FS.readstr(file);
        w96._permissionsys._determinedata._permissionarray=[]; w96._permissionsys._determinedata._formatarr=[]; w96._permissionsys._determinedata._allowed = await w96.FS.readstr("c:/user/appdata/Permi96/allowedPaths.txt"); w96._permissionsys._determinedata._allowed=w96._permissionsys._determinedata._allowed.split(";"); w96._permissionsys._determinedata._allowed.pop();
        if(file.toLowerCase().includes("/system/boot")) return [];
        if(w96._permissionsys._determinedata._allowed.includes(file.toLowerCase().replace("c:",""))) return [];
        if(file.toLowerCase().includes("/system/startup")) return [];
        if(content.toLowerCase().includes("indexeddb")) w96._permissionsys._determinedata._permissionarray.push("indexedDB");
        if(content.toLowerCase().includes("cookie")) w96._permissionsys._determinedata._permissionarray.push("cookie");
        if(content.toLowerCase().includes("localstorage")) w96._permissionsys._determinedata._permissionarray.push("localStorage");
        if(content.toLowerCase().includes("btoa")||content.toLowerCase().includes("atob")) w96._permissionsys._determinedata._permissionarray.push("btoa.atob");
        if(content.toLowerCase().includes("w96.fs") || content.toLowerCase().includes("w96.fsutil") || content.toLowerCase().includes("w96.fsfeatures") || content.toLowerCase().includes("w96.fstype")) w96._permissionsys._determinedata._permissionarray.push("w96.FS_w96.FSUtil_w96.FSFeatures_w96.fstype");
        if(content.toLowerCase().includes("w96.net") || content.toLowerCase().includes("fetch") || content.toLowerCase().includes("xmlhttprequest") || content.toLowerCase().includes("w96.urlopen")) w96._permissionsys._determinedata._permissionarray.push("w96.net_w96.urlopen");
        if(content.toLowerCase().includes("w96.evt")) w96._permissionsys._determinedata._permissionarray.push("w96.evt");
        if(content.toLowerCase().includes("kutil") || content.toLowerCase().includes("w96.ktypes") || content.toLowerCase().includes("w96.main") || content.toLowerCase().includes("w96.main")) w96._permissionsys._determinedata._permissionarray.push("kutil_w96.ktypes_w96.main_w96bld");
        if(content.toLowerCase().includes("w96.shell")) w96._permissionsys._determinedata._permissionarray.push("w96.shell");
        if(content.toLowerCase().includes("w96.state")) w96._permissionsys._determinedata._permissionarray.push("w96.state");
        if(content.toLowerCase().includes("w96.sys") || content.toLowerCase().includes("w96.sysconf")) w96._permissionsys._determinedata._permissionarray.push("w96.sys_w96.sysConf");
        if(content.toLowerCase().includes("w96.wrt")) w96._permissionsys._determinedata._permissionarray.push("w96.WRT");
        if(content.toLowerCase().includes("w96.__debug") || content.toLowerCase().includes("w96.debug")) w96._permissionsys._determinedata._permissionarray.push("debug");
        if(content.toLowerCase().includes("w96._permissionsys")) w96._permissionsys._determinedata._permissionarray.push("w96._permissionsys");
        if(w96.sysConf.get("Software/Permi96/debug")==true) console.log("[PERMI96] permissions: ",w96._permissionsys._determinedata._permissionarray)
        w96._permissionsys._determinedata._permissionarray.forEach((a)=>{
            w96._permissionsys._determinedata._formatarr.push(w96._permissionsys._permissionList[a]);
        })
    
        return w96._permissionsys._determinedata._formatarr.join(", ")
    
    }
    
    
    w96._permissionsys._wrtRunFileCopy = w96.WRT.runFile
    
    w96.WRT.runFile = async function(e,t){
        if(!w96._permissionsys._disabled||!t.boxedEnv.term){
            try {
                if(w96.sysConf.get("Software/Permi96/debug")==true) console.log("[PERMI96] e = "+e+" t = ",t);
                w96._permissionsys._dialog(await w96._permissionsys._determinePerms(e), (a)=>{if(a) {w96._permissionsys._wrtRunFileCopy(e,t)}},e)
            } catch (ex) {
                w96.ui.DialogCreator.alert("<h3>There was an error in Permi96!</h3><br>Share this error code with Permi96's developer:<br><iframe src='data:,"+btoa(JSON.stringify(w96._permissionsys)+";SEPERATOR;"+JSON.stringify($96)+";SEPERATOR;"+JSON.stringify(w96.sys.flags.getAll())+";SEPERATOR;"+w96.sys.env.getEnv("os_ver")+";SEPERATOR;"+ex.stack)+"'></iframe><br><br>The application will be opened and Permi96 will be disabled.",{"title":"Permi96 Error"},()=>{})
                w96._permissionsys._disabled=true
                w96._permissionsys._wrtRunFileCopy(e,t)
            }
        } else {
            w96._permissionsys._wrtRunFileCopy(e,t)
        }
    }
    
    w96._permissionsys._notifclick = function(){
        if(!w96._permissionsys._disabled){
            w96._permissionsys._disabled = true;
            w96.ui.DialogCreator.alert("Permi96 is now disabled.",{"title":"Permi96"},()=>{})
        } else {
            w96._permissionsys._disabled = false;
            w96.ui.DialogCreator.alert("Permi96 is no longer disabled.",{"title":"Permi96"},()=>{})
        }
    }
    w96._permissionsys._notifyicon.setIcon("https://ihategithub9000.github.io/w96-storage/uam.png")
    w96._permissionsys._notifyicon.notifyEl.onclick = w96._permissionsys._notifclick
    
    w96.evt.sys.on('init-complete',()=>{w96.shell.Taskbar.registerNotifyIcon(w96._permissionsys._notifyicon)})
    `);await w96.ui.DialogCreator.alert("Permi96 was installed successfully. You need to reboot Windows 96 to continue. Tip: When Permi96 is installed and running, you see an UAM icon on the taskbar's notification area. Click the icon to disable/enable Permi96",{"title":"Permi96 Installer"});
}();
