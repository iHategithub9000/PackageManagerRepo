w96.FS.writestr('C:/system/boot/sam_ext.js',`w96.sam_ext={}

    w96.sam_ext.lock = function(){
        w96.shell.Taskbar.setVisibility(false)
        document.querySelectorAll('.shell-icon').forEach((x)=>{
            x.style.visibility='hidden'
        })
        w96.WindowSystem.windows.forEach((x)=>{
            if(x!=null){
                if(!x.minimised && x.wndObject){
                    x.wndObject.style.visibility='hidden'
                }
            }
        })
        window._samlockresult=false;
        window._samlockdlg=w96.ui.DialogCreator.prompt("This workstation is locked, please enter the password.", {'icon':'system/resource/icons/win96/32x32/devices/hdd-encrypted.png', 'title': "Workstation Locked", 'buttons':[{'text':'Unlock','id':'ok','action':async function(){
            const isCorrect = await w96.sys.sam.verifyCredentials('user',_samlockdlg.body().querySelector('.w96-textbox').value)
            if (isCorrect) {
                window._samlockresult=true;
                w96.shell.Taskbar.setVisibility(true)
                document.querySelectorAll('.shell-icon').forEach((x)=>{
                    x.style.visibility='initial'
                })
                w96.WindowSystem.windows.forEach((x)=>{
                    if(x!=null){
                        if(!x.minimised && x.wndObject){
                            x.wndObject.style.visibility='initial'
                        }
                    }
                })
                _samlockdlg.close()
            }
        }}]}, ()=>{
            if (!window._samlockresult){
                w96.sam_ext.lock()
            }
        })
        _samlockdlg.body().querySelector('.w96-textbox').type='password'
        _samlockdlg.wnd.center()
    }
    
    w96.sam_ext.auth = function(){
        w96.sam_ext.authdlgdata={}
        w96.sam_ext.authdlgdata.samauthresponse = false;
        w96.sam_ext.authdlgdata.samauthdlg=w96.ui.DialogCreator.prompt("This application requested authentication, please enter the password.", {'icon':'system/resource/icons/win96/32x32/objects/keys.png', 'title': "SAM authenticaton", 'buttons':[{'text':'OK','id':'ok','action':async function(){
            const isCorrect = await w96.sys.sam.verifyCredentials('user',w96.sam_ext.authdlgdata.samauthdlg.body().querySelector('.w96-textbox').value)
            if (isCorrect) {
                w96.sam_ext.authdlgdata.samauthresponse = true;
                w96.sam_ext.authdlgdata.samauthdlg.close()
            }
        }}]}, ()=>{})
        w96.sam_ext.authdlgdata.samauthdlg.body().querySelector('.w96-textbox').type='password'
        w96.sam_ext.authdlgdata.samauthdlg.wnd.center()
    }`)
    
    alert('SAM extensions installed, reboot please!')