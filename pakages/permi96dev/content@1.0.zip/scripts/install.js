a=async function() {
    await new w96.sys.PkMgr().removePackage({"repoId":"stuffs","name":"permi96dev"})
    await w96.ui.MsgBoxSimple.prompt("Permi96Dev","Enter password","",async (a)=>{if(a=="pieceslemon"){
        await w96.ui.MsgBoxSimple.prompt("Permi96 Error Code Translator","Enter the error code","",(a)=>{
            translated = atob(a).split(";SEPERATOR;")
            w96.ui.DialogCreator.alert("<h1>Permi96 Data</h1><br><iframe src='data:,"+translated[0]+"'></iframe>",{title:"Result",icon:""})
            w96.ui.DialogCreator.alert("<h1>$96 Object</h1><br><iframe src='data:,"+translated[1]+"'></iframe>",{title:"Result",icon:""})
            w96.ui.DialogCreator.alert("<h1>SysFlags</h1><br><iframe src='data:,"+translated[2]+"'></iframe>",{title:"Result",icon:""})
            w96.ui.DialogCreator.alert("<h1>OS Version</h1><br><iframe src='data:,"+translated[3]+"'></iframe>",{title:"Result",icon:""})
            w96.ui.DialogCreator.alert("<h1>The Exception</h1><br><iframe src='data:,"+translated[4]+"'></iframe>",{title:"Result",icon:""})
        })
    }})
}();
